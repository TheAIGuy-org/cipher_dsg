from __future__ import annotations

import json
import os
import re

from openpyxl import Workbook, load_workbook
from pydantic import BaseModel
from typing import List

from dotenv import load_dotenv
from llm.azure_client import get_llm_client
from updater.prompt import TableUpdatePrompts

load_dotenv()


# ─────────────────────────────────────────────
# Output schema
# ─────────────────────────────────────────────
class OutputFormat(BaseModel):
    rows:    List[List[str]]
    headers: List[str]


# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────
def extract_rows(table_str: str) -> list[str]:
    """
    Extract all table content from a raw string including:
    - Pipe-delimited rows (| col | col |) — handles multi-line rows where a
      single logical row is split across lines mid-cell
    - Trailing totals line without pipes (e.g. "100.00  91.95  75.20")
    - Trailing summary sentence (e.g. "The percentage of natural origin...")
    """
    rows        = []
    in_table    = False
    blank_count = 0
    pending     = ""   # accumulates a multi-line row fragment

    def _flush(pending: str) -> str | None:
        """Return a completed row string if pending forms a valid row, else None."""
        s = pending.strip()
        if not s:
            return None
        # It's a complete row if it starts AND ends with |
        if s.startswith("|") and s.endswith("|"):
            # Skip pure separator lines
            if set(s.replace("|", "").strip()) <= {"-", " "}:
                return None
            return s.strip("|").strip()
        return None

    for line in table_str.split("\n"):
        stripped = line.strip()

        # ── Pipe content ─────────────────────────────────────────────────────
        if "|" in stripped:
            blank_count = 0
            in_table    = True

            # Accumulate — a row may be split across multiple lines
            if pending:
                pending = pending.rstrip() + " " + stripped
            else:
                pending = stripped

            # Check if accumulated pending forms a complete row
            completed = _flush(pending)
            if completed is not None:
                rows.append(completed)
                pending = ""
            continue

        # ── After table has started, no pipe ─────────────────────────────────
        if in_table:
            # Flush any pending incomplete row first
            if pending:
                completed = _flush(pending)
                if completed:
                    rows.append(completed)
                pending = ""

            if not stripped:
                blank_count += 1
                if blank_count > 1:
                    in_table = False
                continue

            blank_count = 0

            # Totals row — digits/spaces/dots only
            if re.match(r"^[\d\s.,]+$", stripped):
                rows.append(stripped)
                continue

            # Summary sentence
            if re.match(r"^The\s+percentage", stripped, re.IGNORECASE):
                rows.append(stripped)
                in_table = False
                continue

            # Other non-empty continuation line
            rows.append(stripped)
            continue

    # Flush any remaining pending row
    if pending:
        completed = _flush(pending)
        if completed:
            rows.append(completed)

    print(f"Extracted {len(rows)} rows")
    return rows


def get_table_name(folder_path: str, keywords: list[str]) -> str | None:
    """Score each xlsx in folder_path against keywords and return the best match."""
    best_file  = None
    best_score = -1

    for file in os.listdir(folder_path):
        if not file.endswith(".xlsx"):
            continue

        path = os.path.join(folder_path, file)
        wb   = load_workbook(path)
        ws   = wb.active

        data = [
            [str(cell).lower() if cell else "" for cell in row]
            for row in ws.iter_rows(values_only=True)
        ]

        if not data:
            continue

        score = 0

        header_text = " ".join(data[0])
        for kw in keywords:
            if kw.lower() in header_text:
                score += 5

        for row in data:
            row_text = " ".join(row)
            for kw in keywords:
                if kw.lower() in row_text:
                    score += 1

        col_counts = [len(r) for r in data]
        if len(set(col_counts)) == 1:
            score += 2

        if len(data) < 2:
            score -= 5

        if score > best_score:
            best_score = score
            best_file  = file

    print(f"Best matching file: {best_file}")
    return best_file


def llm_parse_row(rows: list[str], folder_path: str) -> tuple[list, list, str | None]:
    """Send raw rows to the LLM, get back structured headers + data."""
    print("Using LLM to parse rows into structured data")

    user_prompt   = TableUpdatePrompts.USER_PROMPT.format(rows=str(rows))
    system_prompt = TableUpdatePrompts.SYSTEM_PROMPT

    response = get_llm_client().ask(
        prompt          = user_prompt,
        system_prompt   = system_prompt,
        response_format = "json_object",
        temperature     = 0,
    )

    if not response.success:
        raise Exception(f"LLM call failed: {response.error}")

    structured = OutputFormat(**response.content)
    FILE       = get_table_name(folder_path, structured.headers)

    return structured.rows, structured.headers, FILE


# ─────────────────────────────────────────────
# Main entry point
# ─────────────────────────────────────────────
def extract_trailing_text(table_str: str) -> list[str]:
    """
    Return non-table lines from table_str (totals row + summary sentence)
    that should be added to the DOCX as paragraphs after the table.
    """
    trailing = []
    in_table = False
    for line in table_str.split("\n"):
        s = line.strip()
        if "|" in s:
            in_table = True
            continue
        if in_table and s:
            if in_table and s and "|" not in s:
                trailing.append(s)
    print(trailing)
    return trailing


def table_to_excel_llm(table_str: str, folder_path: str) -> list[str]:
    """
    Parse ONLY the pipe-delimited table rows and overwrite the matching
    Excel file. Totals lines and summary sentences are ignored — they
    already exist in the original xlsx and struct.
    """
    print("Making necessary changes to the Excel file")

    all_rows = extract_rows(table_str)
    if not all_rows:
        print("No table rows found — skipping Excel update")
        return

    # Keep ONLY pipe-delimited rows — drop totals and summary lines
    pipe_rows = [
        r for r in all_rows
        if not re.match(r"^[\d\s.,]+$", r.strip())           # not a totals line
        and not re.match(r"^The\s+percentage", r.strip(), re.IGNORECASE)  # not summary
    ]

    if not pipe_rows:
        print("No pipe rows after filtering — skipping Excel update")
        return

    data, headers, FILE = llm_parse_row(pipe_rows, folder_path)

    if not FILE:
        raise ValueError(f"No matching Excel table found in: {folder_path}")

    file_path = os.path.join(folder_path, FILE)
    print(f"Overwriting: {file_path}")

    wb = Workbook()
    ws = wb.active
    ws.title = "Table"

    ws.append(headers)
    for item in data:
        row_values = list(item)
        while len(row_values) < len(headers):
            row_values.append("")
        ws.append(row_values)

    wb.save(file_path)
    print(f"✅ Excel overwritten: {file_path}")

    # Return trailing lines so caller can inject them into the DOCX struct
    return extract_trailing_text(table_str)