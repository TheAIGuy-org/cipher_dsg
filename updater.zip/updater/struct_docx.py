from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from typing import Any

from docx import Document
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from openpyxl import load_workbook

from config.settings import settings

OUTPUT_DIR = settings.PROJECT_ROOT / "output"

# Bullet characters recognised everywhere
_BULLET_RE = r"[•‣◦⁃\-]"


def clean_text(value: Any) -> str:
    if value is None:
        return ""
    value = str(value)
    value = re.sub(r"_x000D_", "", value)
    value = value.replace("\r", "").replace("\n", " ")
    value = re.sub(r"\s+", " ", value)
    # Strip XML-incompatible control characters
    value = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", value)
    return value.strip()


def _strip_bullet_char(text: str) -> str:
    """Remove leading bullet character — List Bullet style adds its own."""
    return re.sub(rf"^{_BULLET_RE}\s*", "", text)


def _split_inline_bullets(text: str) -> list[tuple[str, bool]]:
    """
    Split text on embedded bullet chars (•‣◦⁃) or detect a leading dash/bullet.
    Returns list of (text, is_bullet) tuples.
    """
    stripped = text.strip()

    # Whole line starts with a bullet char (including dash)
    if re.match(rf"^{_BULLET_RE}\s", stripped):
        return [(_strip_bullet_char(stripped), True)]

    # Bullet chars embedded mid-string (split on •‣◦⁃ only, not dash)
    parts = re.split(r"[•‣◦⁃]", text)
    if len(parts) == 1:
        return [(text, False)]

    result = []
    for i, part in enumerate(parts):
        part = part.strip()
        if not part:
            continue
        result.append((part, i > 0))
    return result


def _add_toc_line(doc, label: str, page_num: str) -> None:
    """Add a TOC entry with right-aligned dot-leader tab stop."""
    p   = doc.add_paragraph()
    pPr = p._p.get_or_add_pPr()

    for existing in pPr.findall(qn("w:tabs")):
        pPr.remove(existing)

    tabs_el = OxmlElement("w:tabs")
    tab_el  = OxmlElement("w:tab")
    tab_el.set(qn("w:val"),    "right")
    tab_el.set(qn("w:leader"), "dot")
    tab_el.set(qn("w:pos"),    "8640")   # ~15.2cm in twips
    tabs_el.append(tab_el)
    pPr.append(tabs_el)

    p.add_run(label)

    # Tab must be a <w:tab/> XML element, not a \t character
    r_tab = OxmlElement("w:r")
    r_tab.append(OxmlElement("w:tab"))
    p._p.append(r_tab)

    p.add_run(page_num)


def struct_to_docx(struct_dict: dict[str, Any], product_code: str) -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # Locate the extracted folder matching this product code
    _matches = list(settings.DOSSIER_DIR.glob(f"*_{product_code}.pdf"))
    if _matches:
        extracted_dir = settings.PROJECT_ROOT / "data" / "extracted" / _matches[0].stem
    else:
        extracted_dir = next(
            (settings.PROJECT_ROOT / "data" / "extracted").glob(f"*{product_code}*"),
            settings.PROJECT_ROOT / "data" / "extracted" / product_code,
        )

    doc             = Document()
    skip_mode       = False
    pending_bullet  = False
    last_was_bullet = False
    elements        = struct_dict.get("elements", [])
    consumed        = set()  # indices absorbed by peek-forward TOC logic

    for idx, element in enumerate(elements):
        if idx in consumed:
            continue

        path       = element.get("Path", "")
        text       = element.get("Text", "") or ""
        file_paths = element.get("filePaths")

        # ── 1. TABLE FROM XLSX ────────────────────────────────────────────────
        if file_paths:
            skip_mode       = True
            last_was_bullet = False
            xlsx_file       = extracted_dir / file_paths[0]

            if not xlsx_file.exists():
                print(f"❌ Missing table: {xlsx_file}")
                continue

            print(f"📊 Inserting table: {xlsx_file}")
            wb    = load_workbook(xlsx_file, data_only=True)
            ws    = wb.active
            rows  = [r for r in ws.iter_rows(values_only=True)
                     if any(c is not None and str(c).strip() for c in r)]

            if rows:
                table       = doc.add_table(rows=len(rows), cols=len(rows[0]))
                table.style = "Table Grid"
                for i, row in enumerate(rows):
                    for j, cell in enumerate(row):
                        table.rows[i].cells[j].text = clean_text(cell)

            doc.add_paragraph("")
            continue

        # ── 2. SKIP TABLE CELL TEXT ───────────────────────────────────────────
        if skip_mode:
            if any(tag in path for tag in ("H1", "H2", "H3")):
                skip_mode = False
            elif not any(tag in path for tag in ("TR", "TH", "TD", "Table")):
                # Non-table-cell element after a table — stop skipping
                # This allows injected P elements (summary lines) to render
                skip_mode = False
            else:
                continue

        # ── 3. TOC ENTRIES ────────────────────────────────────────────────────
        if "TOC" in path:
            if text and text.strip():
                # Pre-tabbed: Adobe already joined label\tpage
                if "\t" in text:
                    parts    = text.split("\t", 1)
                    label    = parts[0].rstrip(". ")
                    page_num = parts[1].strip() if len(parts) > 1 else None
                    if page_num:
                        _add_toc_line(doc, label, page_num)
                    elif label:
                        doc.add_paragraph(label)
                else:
                    # Peek forward to collect page number fragment
                    entry_parts = [clean_text(text)]
                    page_num    = None
                    j = idx + 1
                    while j < len(elements):
                        nxt      = elements[j]
                        nxt_path = nxt.get("Path", "")
                        nxt_text = (nxt.get("Text") or "").strip()
                        if "TOC" not in nxt_path:
                            break
                        if re.match(r"^[0-9]+[.][0-9]+", nxt_text) or re.match(
                            r"^(Table|Figure)\s+[0-9]+", nxt_text, re.IGNORECASE
                        ):
                            break
                        if nxt_text:
                            if re.match(r"^[0-9]+$", nxt_text):
                                page_num = nxt_text
                            else:
                                entry_parts.append(clean_text(nxt_text))
                        consumed.add(j)
                        j += 1

                    label = "  ".join(entry_parts).rstrip(". ")
                    if page_num:
                        _add_toc_line(doc, label, page_num)
                    else:
                        doc.add_paragraph(label)
            continue

        # TOC section title (Table of contents / tables / figures)
        if text and re.match(r"^Table of (contents|tables|figures)", text.strip(), re.IGNORECASE):
            from docx.shared import Pt
            p   = doc.add_paragraph()
            run = p.add_run(clean_text(text))
            run.bold      = True
            run.font.size = Pt(12)
            continue

        # ── 4. BULLET SYMBOL (Lbl) ────────────────────────────────────────────
        if "Lbl" in path:
            pending_bullet = True
            continue

        # ── 5. BULLET BODY (LBody after Lbl) ─────────────────────────────────
        if pending_bullet:
            clean = _strip_bullet_char(clean_text(text))
            if clean:
                doc.add_paragraph(clean, style="List Bullet")
                last_was_bullet = True
            pending_bullet = False
            continue

        # ── 6. ORPHAN LBODY ───────────────────────────────────────────────────
        if "LBody" in path:
            clean = _strip_bullet_char(clean_text(text))
            if clean:
                doc.add_paragraph(clean, style="List Bullet")
                last_was_bullet = True
            continue

        # ── 7. NORMAL CONTENT ─────────────────────────────────────────────────
        if text and text.strip():
            clean = clean_text(text)

            if last_was_bullet and not any(b for _, b in _split_inline_bullets(clean)):
                doc.add_paragraph("")
                last_was_bullet = False

            if "H1" in path:
                doc.add_heading(clean, level=1)
            elif "H2" in path:
                doc.add_heading(clean, level=2)
            elif "H3" in path:
                doc.add_heading(clean, level=3)
            else:
                for chunk_text, is_bullet in _split_inline_bullets(clean):
                    if is_bullet:
                        doc.add_paragraph(chunk_text, style="List Bullet")
                        last_was_bullet = True
                    else:
                        doc.add_paragraph(chunk_text)
        else:
            if last_was_bullet and not pending_bullet:
                last_was_bullet = False

    ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = OUTPUT_DIR / f"{product_code}_{ts}.docx"
    doc.save(out_path)
    print(f"\n✅ DOCX saved: {out_path}")
    return out_path